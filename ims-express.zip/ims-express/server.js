const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
const bcrypt = require('bcryptjs');
const { v4: uuidv4 } = require('uuid');
const moment = require('moment');

const app = express();
const PORT = process.env.PORT || 3000;

// Ensure data directory exists
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir);
}

// Database file path
const dbPath = path.join(dataDir, 'database.json');

// Initialize database if not exists or empty
const initializeDatabase = () => {
    const initialData = {
        users: [
            {
                id: uuidv4(),
                username: 'admin',
                password: bcrypt.hashSync('admin123', 10),
                email: 'admin@ims.com',
                role: 'admin',
                created: new Date().toISOString()
            }
        ],
        products: [
            {
                id: uuidv4(),
                name: 'Laptop Dell XPS 15',
                sku: 'PRD-001',
                category: 'Electronics',
                price: 1499.99,
                cost: 1200.00,
                quantity: 25,
                minStock: 10,
                location: 'A-12',
                supplier: 'Tech Supplies Inc',
                lastUpdated: new Date().toISOString(),
                description: 'High-performance laptop with 16GB RAM, 1TB SSD'
            },
            {
                id: uuidv4(),
                name: 'Wireless Mouse',
                sku: 'PRD-002',
                category: 'Accessories',
                price: 49.99,
                cost: 35.00,
                quantity: 150,
                minStock: 50,
                location: 'B-03',
                supplier: 'Peripherals Co',
                lastUpdated: new Date().toISOString(),
                description: 'Ergonomic wireless mouse with Bluetooth'
            },
            {
                id: uuidv4(),
                name: 'Gaming Monitor 27"',
                sku: 'PRD-003',
                category: 'Electronics',
                price: 399.99,
                cost: 320.00,
                quantity: 15,
                minStock: 5,
                location: 'C-07',
                supplier: 'Tech Supplies Inc',
                lastUpdated: new Date().toISOString(),
                description: '27-inch 144Hz gaming monitor'
            }
        ],
        suppliers: [
            {
                id: uuidv4(),
                name: 'Tech Supplies Inc',
                contact: 'John Smith',
                email: 'john@techsupplies.com',
                phone: '+1 (555) 123-4567',
                address: '123 Tech Street, Silicon Valley, CA',
                productsSupplied: ['Laptops', 'Monitors', 'Accessories'],
                rating: 4.8,
                lastOrder: '2024-01-15'
            },
            {
                id: uuidv4(),
                name: 'Peripherals Co',
                contact: 'Sarah Johnson',
                email: 'sarah@peripherals.co',
                phone: '+1 (555) 987-6543',
                address: '456 Accessory Ave, New York, NY',
                productsSupplied: ['Mice', 'Keyboards', 'Headsets'],
                rating: 4.5,
                lastOrder: '2024-01-10'
            }
        ],
        sales: [
            {
                id: uuidv4(),
                productId: 'PRD-001',
                productName: 'Laptop Dell XPS 15',
                quantity: 2,
                price: 1499.99,
                total: 2999.98,
                customer: 'ABC Corporation',
                date: new Date().toISOString(),
                status: 'completed'
            },
            {
                id: uuidv4(),
                productId: 'PRD-002',
                productName: 'Wireless Mouse',
                quantity: 10,
                price: 49.99,
                total: 499.90,
                customer: 'XYZ Ltd',
                date: new Date(Date.now() - 86400000).toISOString(), // Yesterday
                status: 'completed'
            }
        ],
        stockHistory: []
    };
    
    fs.writeFileSync(dbPath, JSON.stringify(initialData, null, 2));
    console.log('✅ Database initialized with sample data');
    return initialData;
};

// Database helper functions with error handling
const readDB = () => {
    try {
        if (!fs.existsSync(dbPath) || fs.statSync(dbPath).size === 0) {
            console.log('⚠️ Database file empty or missing, initializing...');
            return initializeDatabase();
        }
        
        const data = fs.readFileSync(dbPath, 'utf8');
        const parsed = JSON.parse(data);
        
        // Ensure all required fields exist
        if (!parsed.users || !parsed.products || !parsed.suppliers || !parsed.sales || !parsed.stockHistory) {
            console.log('⚠️ Database structure incomplete, reinitializing...');
            return initializeDatabase();
        }
        
        return parsed;
    } catch (error) {
        console.error('❌ Error reading database:', error.message);
        console.log('🔄 Reinitializing database...');
        return initializeDatabase();
    }
};

const writeDB = (data) => {
    try {
        fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));
        return true;
    } catch (error) {
        console.error('❌ Error writing to database:', error.message);
        return false;
    }
};

// Initialize database on server start
console.log('🔍 Checking database...');
readDB();

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(session({
    secret: 'ims-express-secret-key-2024-change-this-in-production',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        maxAge: 1000 * 60 * 60 * 24, // 24 hours
        secure: false, // Set to true in production with HTTPS
        httpOnly: true
    }
}));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static files
app.use(express.static(path.join(__dirname, 'public')));

// Authentication middleware
const requireAuth = (req, res, next) => {
    if (!req.session.user) {
        return res.redirect('/login');
    }
    next();
};

// Routes

// Home/Landing page
app.get('/', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('index', { user: req.session.user });
});

// Login page
app.get('/login', (req, res) => {
    if (req.session.user) {
        return res.redirect('/dashboard');
    }
    res.render('login', { error: null });
});

// Login POST
app.post('/login', (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.render('login', { error: 'Username and password are required' });
        }
        
        const db = readDB();
        const user = db.users.find(u => u.username === username);
        
        if (user && bcrypt.compareSync(password, user.password)) {
            req.session.user = {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role
            };
            console.log(`✅ User ${username} logged in successfully`);
            return res.redirect('/dashboard');
        }
        
        res.render('login', { error: 'Invalid username or password' });
    } catch (error) {
        console.error('❌ Login error:', error);
        res.render('login', { error: 'An error occurred during login' });
    }
});

// Logout
app.get('/logout', (req, res) => {
    if (req.session.user) {
        console.log(`👋 User ${req.session.user.username} logged out`);
    }
    req.session.destroy();
    res.redirect('/');
});

// Dashboard
app.get('/dashboard', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const stats = {
            totalProducts: db.products.length,
            lowStock: db.products.filter(p => p.quantity <= p.minStock).length,
            totalValue: db.products.reduce((sum, p) => sum + (p.quantity * p.cost), 0),
            totalSales: db.sales.reduce((sum, s) => sum + s.total, 0),
            totalSuppliers: db.suppliers.length
        };
        
        // Recent activity
        const recentSales = db.sales.slice(-5).reverse();
        const lowStockItems = db.products.filter(p => p.quantity <= p.minStock);
        
        res.render('dashboard', { 
            user: req.session.user, 
            stats,
            recentSales,
            lowStockItems,
            moment
        });
    } catch (error) {
        console.error('❌ Dashboard error:', error);
        res.status(500).render('error', { 
            user: req.session.user, 
            error: 'Failed to load dashboard data' 
        });
    }
});

// Products management
app.get('/products', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const products = db.products;
        const suppliers = db.suppliers;
        res.render('products', { 
            user: req.session.user, 
            products,
            suppliers,
            moment
        });
    } catch (error) {
        console.error('❌ Products error:', error);
        res.status(500).render('error', { 
            user: req.session.user, 
            error: 'Failed to load products' 
        });
    }
});

// Add product
app.post('/products/add', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const newProduct = {
            id: uuidv4(),
            name: req.body.name,
            sku: req.body.sku,
            category: req.body.category,
            price: parseFloat(req.body.price),
            cost: parseFloat(req.body.cost),
            quantity: parseInt(req.body.quantity),
            minStock: parseInt(req.body.minStock),
            location: req.body.location,
            supplier: req.body.supplier,
            description: req.body.description,
            lastUpdated: new Date().toISOString()
        };
        
        db.products.push(newProduct);
        if (writeDB(db)) {
            console.log(`✅ Product "${newProduct.name}" added successfully`);
        }
        res.redirect('/products');
    } catch (error) {
        console.error('❌ Add product error:', error);
        res.redirect('/products');
    }
});

// Update product
app.post('/products/update/:id', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const index = db.products.findIndex(p => p.id === req.params.id);
        
        if (index !== -1) {
            db.products[index] = {
                ...db.products[index],
                ...req.body,
                price: parseFloat(req.body.price),
                cost: parseFloat(req.body.cost),
                quantity: parseInt(req.body.quantity),
                minStock: parseInt(req.body.minStock),
                lastUpdated: new Date().toISOString()
            };
            if (writeDB(db)) {
                console.log(`✅ Product "${db.products[index].name}" updated successfully`);
            }
        }
        res.redirect('/products');
    } catch (error) {
        console.error('❌ Update product error:', error);
        res.redirect('/products');
    }
});

// Delete product
app.get('/products/delete/:id', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const product = db.products.find(p => p.id === req.params.id);
        db.products = db.products.filter(p => p.id !== req.params.id);
        if (writeDB(db)) {
            console.log(`✅ Product "${product?.name || req.params.id}" deleted successfully`);
        }
        res.redirect('/products');
    } catch (error) {
        console.error('❌ Delete product error:', error);
        res.redirect('/products');
    }
});

// Stock management
app.get('/stock', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const products = db.products;
        res.render('stock', { 
            user: req.session.user, 
            products,
            moment
        });
    } catch (error) {
        console.error('❌ Stock error:', error);
        res.status(500).render('error', { 
            user: req.session.user, 
            error: 'Failed to load stock data' 
        });
    }
});

// Update stock
app.post('/stock/update', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const { productId, action, quantity, notes } = req.body;
        const productIndex = db.products.findIndex(p => p.id === productId);
        
        if (productIndex !== -1) {
            const product = db.products[productIndex];
            const oldQuantity = product.quantity;
            const qty = parseInt(quantity) || 0;
            
            if (action === 'add') {
                product.quantity += qty;
            } else if (action === 'remove') {
                product.quantity = Math.max(0, product.quantity - qty);
            } else if (action === 'set') {
                product.quantity = qty;
            }
            
            // Record in history
            db.stockHistory.push({
                id: uuidv4(),
                productId: product.id,
                productName: product.name,
                action,
                quantity: qty,
                oldQuantity,
                newQuantity: product.quantity,
                notes,
                date: new Date().toISOString(),
                user: req.session.user.username
            });
            
            product.lastUpdated = new Date().toISOString();
            if (writeDB(db)) {
                console.log(`✅ Stock updated for "${product.name}"`);
            }
        }
        
        res.redirect('/stock');
    } catch (error) {
        console.error('❌ Stock update error:', error);
        res.redirect('/stock');
    }
});

// Suppliers management
app.get('/suppliers', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const suppliers = db.suppliers;
        res.render('suppliers', { 
            user: req.session.user, 
            suppliers,
            moment
        });
    } catch (error) {
        console.error('❌ Suppliers error:', error);
        res.status(500).render('error', { 
            user: req.session.user, 
            error: 'Failed to load suppliers' 
        });
    }
});

// Add supplier
app.post('/suppliers/add', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const newSupplier = {
            id: uuidv4(),
            name: req.body.name,
            contact: req.body.contact,
            email: req.body.email,
            phone: req.body.phone,
            address: req.body.address,
            productsSupplied: req.body.productsSupplied ? 
                req.body.productsSupplied.split(',').map(p => p.trim()) : [],
            rating: parseFloat(req.body.rating) || 0,
            lastOrder: req.body.lastOrder || null
        };
        
        db.suppliers.push(newSupplier);
        if (writeDB(db)) {
            console.log(`✅ Supplier "${newSupplier.name}" added successfully`);
        }
        res.redirect('/suppliers');
    } catch (error) {
        console.error('❌ Add supplier error:', error);
        res.redirect('/suppliers');
    }
});

// Delete supplier
app.get('/suppliers/delete/:id', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const supplier = db.suppliers.find(s => s.id === req.params.id);
        db.suppliers = db.suppliers.filter(s => s.id !== req.params.id);
        if (writeDB(db)) {
            console.log(`✅ Supplier "${supplier?.name || req.params.id}" deleted successfully`);
        }
        res.redirect('/suppliers');
    } catch (error) {
        console.error('❌ Delete supplier error:', error);
        res.redirect('/suppliers');
    }
});

// Sales tracking
app.get('/sales', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const sales = db.sales;
        const products = db.products;
        res.render('sales', { 
            user: req.session.user, 
            sales: sales.reverse(),
            products,
            moment
        });
    } catch (error) {
        console.error('❌ Sales error:', error);
        res.status(500).render('error', { 
            user: req.session.user, 
            error: 'Failed to load sales data' 
        });
    }
});

// Add sale
app.post('/sales/add', requireAuth, (req, res) => {
    try {
        const db = readDB();
        const product = db.products.find(p => p.id === req.body.productId);
        
        if (!product) {
            return res.redirect('/sales?error=Product not found');
        }
        
        const quantity = parseInt(req.body.quantity) || 0;
        if (quantity <= 0) {
            return res.redirect('/sales?error=Invalid quantity');
        }
        
        if (product.quantity < quantity) {
            return res.redirect(`/sales?error=Insufficient stock. Available: ${product.quantity}`);
        }
        
        const newSale = {
            id: uuidv4(),
            productId: product.id,
            productName: product.name,
            quantity,
            price: product.price,
            total: quantity * product.price,
            customer: req.body.customer,
            date: new Date().toISOString(),
            status: 'completed'
        };
        
        // Update product stock
        product.quantity -= quantity;
        product.lastUpdated = new Date().toISOString();
        
        db.sales.push(newSale);
        if (writeDB(db)) {
            console.log(`✅ Sale recorded: ${quantity}x ${product.name} to ${req.body.customer}`);
        }
        
        res.redirect('/sales');
    } catch (error) {
        console.error('❌ Add sale error:', error);
        res.redirect('/sales?error=Failed to record sale');
    }
});

// API Endpoints for charts
app.get('/api/dashboard-stats', requireAuth, (req, res) => {
    try {
        const db = readDB();
        
        // Category distribution
        const categories = {};
        db.products.forEach(p => {
            categories[p.category] = (categories[p.category] || 0) + 1;
        });
        
        // Sales by month (last 6 months)
        const salesByMonth = {};
        const sixMonthsAgo = moment().subtract(6, 'months');
        
        db.sales.forEach(sale => {
            const month = moment(sale.date).format('MMM YYYY');
            if (moment(sale.date).isAfter(sixMonthsAgo)) {
                salesByMonth[month] = (salesByMonth[month] || 0) + sale.total;
            }
        });
        
        // Ensure we have data for last 6 months
        const months = [];
        for (let i = 5; i >= 0; i--) {
            months.push(moment().subtract(i, 'months').format('MMM YYYY'));
        }
        
        months.forEach(month => {
            if (!salesByMonth[month]) {
                salesByMonth[month] = 0;
            }
        });
        
        res.json({
            success: true,
            categories,
            salesByMonth,
            lowStockCount: db.products.filter(p => p.quantity <= p.minStock).length,
            totalProducts: db.products.length
        });
    } catch (error) {
        console.error('❌ API error:', error);
        res.status(500).json({
            success: false,
            error: 'Failed to load dashboard stats'
        });
    }
});

// Error page
app.get('/error', (req, res) => {
    res.render('error', { 
        user: req.session.user, 
        error: req.query.error || 'An error occurred' 
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).render('error', { 
        user: req.session.user, 
        error: 'Page not found' 
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('❌ Server error:', err);
    res.status(500).render('error', { 
        user: req.session.user, 
        error: 'Internal server error' 
    });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 IMS Express Server running on http://localhost:${PORT}`);
    console.log(`📊 Default login credentials:`);
    console.log(`   👤 Username: admin`);
    console.log(`   🔑 Password: admin123`);
    console.log(`\n📁 Database file: ${dbPath}`);
    console.log(`👀 Check if database.json exists and has valid data`);
});