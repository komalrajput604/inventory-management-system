# IMS Express - Professional Inventory Management System

![IMS Express](https://img.shields.io/badge/IMS-Express-blue)
![Node.js](https://img.shields.io/badge/Node.js-18+-green)
![Express](https://img.shields.io/badge/Express-4.x-lightgrey)
![License](https://img.shields.io/badge/License-MIT-yellow)

A professional, feature-rich Inventory Management System built with Node.js, Express, and EJS. Manage your inventory, track sales, handle suppliers, and get real-time insights with beautiful dashboards.

## 🌟 Features

- **Dashboard**: Real-time statistics and analytics with interactive charts
- **Product Management**: Add, edit, delete, and track products with SKU support
- **Stock Management**: Track stock levels with low-stock alerts
- **Supplier Management**: Manage supplier information and ratings
- **Sales Tracking**: Record sales and generate invoices
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Export Data**: Export inventory, sales, and supplier data to CSV
- **User Authentication**: Secure login system with session management
- **Real-time Charts**: Visualize data with Chart.js integration

## 🚀 Quick Start

### Prerequisites
- Node.js 18 or higher
- npm or yarn

### Installation

1. **Clone the repository**
```bash
git clone <repository-url>
cd ims-express