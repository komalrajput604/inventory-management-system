// Global variables
let salesChart = null;
let categoryChart = null;

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initTooltips();
    
    // Initialize charts if on dashboard
    if (document.getElementById('salesChart')) {
        loadDashboardCharts();
        setInterval(loadDashboardCharts, 30000); // Refresh every 30 seconds
    }
    
    // Initialize modals
    initModals();
    
    // Initialize form validation
    initFormValidation();
    
    // Initialize search functionality
    initSearch();
    
    // Auto-hide alerts after 5 seconds
    autoHideAlerts();
});

// Initialize Bootstrap-like tooltips
function initTooltips() {
    const tooltipElements = document.querySelectorAll('[data-tooltip]');
    tooltipElements.forEach(el => {
        el.addEventListener('mouseenter', showTooltip);
        el.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(e) {
    const tooltipText = this.getAttribute('data-tooltip');
    const tooltip = document.createElement('div');
    tooltip.className = 'custom-tooltip';
    tooltip.textContent = tooltipText;
    tooltip.style.position = 'absolute';
    tooltip.style.background = 'rgba(0, 0, 0, 0.8)';
    tooltip.style.color = 'white';
    tooltip.style.padding = '5px 10px';
    tooltip.style.borderRadius = '4px';
    tooltip.style.fontSize = '12px';
    tooltip.style.zIndex = '1000';
    tooltip.style.whiteSpace = 'nowrap';
    
    const rect = this.getBoundingClientRect();
    tooltip.style.top = (rect.top - 30) + 'px';
    tooltip.style.left = (rect.left + rect.width / 2) + 'px';
    tooltip.style.transform = 'translateX(-50%)';
    
    this.tooltipElement = tooltip;
    document.body.appendChild(tooltip);
}

function hideTooltip() {
    if (this.tooltipElement) {
        this.tooltipElement.remove();
        this.tooltipElement = null;
    }
}

// Load dashboard charts
async function loadDashboardCharts() {
    try {
        const response = await fetch('/api/dashboard-stats');
        const data = await response.json();
        
        // Update stats counters with animation
        animateValue('totalProducts', data.categories ? Object.values(data.categories).reduce((a, b) => a + b, 0) : 0);
        animateValue('lowStockCount', data.lowStockCount || 0);
        
        // Create or update sales chart
        const salesCtx = document.getElementById('salesChart').getContext('2d');
        const salesLabels = Object.keys(data.salesByMonth || {});
        const salesData = Object.values(data.salesByMonth || {});
        
        if (salesChart) {
            salesChart.destroy();
        }
        
        salesChart = new Chart(salesCtx, {
            type: 'line',
            data: {
                labels: salesLabels,
                datasets: [{
                    label: 'Sales ($)',
                    data: salesData,
                    borderColor: '#4361ee',
                    backgroundColor: 'rgba(67, 97, 238, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0, 0, 0, 0.05)'
                        },
                        ticks: {
                            callback: function(value) {
                                return '$' + value.toLocaleString();
                            }
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                }
            }
        });
        
        // Create or update category chart
        const categoryCtx = document.getElementById('categoryChart').getContext('2d');
        const categoryLabels = Object.keys(data.categories || {});
        const categoryData = Object.values(data.categories || {});
        
        if (categoryChart) {
            categoryChart.destroy();
        }
        
        categoryChart = new Chart(categoryCtx, {
            type: 'doughnut',
            data: {
                labels: categoryLabels,
                datasets: [{
                    data: categoryData,
                    backgroundColor: [
                        '#4361ee',
                        '#7209b7',
                        '#4cc9f0',
                        '#f72585',
                        '#f8961e',
                        '#4895ef'
                    ],
                    borderWidth: 2,
                    borderColor: 'white'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'right',
                        labels: {
                            padding: 20
                        }
                    }
                }
            }
        });
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Animate counter values
function animateValue(elementId, targetValue) {
    const element = document.getElementById(elementId);
    if (!element) return;
    
    const currentValue = parseInt(element.textContent.replace(/[^0-9]/g, '') || '0');
    const duration = 1000; // 1 second
    const steps = 60;
    const stepValue = (targetValue - currentValue) / steps;
    let currentStep = 0;
    
    const timer = setInterval(() => {
        if (currentStep >= steps) {
            element.textContent = targetValue.toLocaleString();
            clearInterval(timer);
            return;
        }
        
        const value = Math.round(currentValue + (stepValue * currentStep));
        element.textContent = value.toLocaleString();
        currentStep++;
    }, duration / steps);
}

// Initialize modals
function initModals() {
    // Add product modal
    const addProductBtn = document.getElementById('addProductBtn');
    const addProductModal = document.getElementById('addProductModal');
    
    if (addProductBtn && addProductModal) {
        addProductBtn.addEventListener('click', () => {
            addProductModal.style.display = 'flex';
        });
        
        addProductModal.addEventListener('click', (e) => {
            if (e.target === addProductModal || e.target.closest('.close-modal')) {
                addProductModal.style.display = 'none';
            }
        });
    }
    
    // Add sale modal
    const addSaleBtn = document.getElementById('addSaleBtn');
    const addSaleModal = document.getElementById('addSaleModal');
    
    if (addSaleBtn && addSaleModal) {
        addSaleBtn.addEventListener('click', () => {
            addSaleModal.style.display = 'flex';
        });
        
        addSaleModal.addEventListener('click', (e) => {
            if (e.target === addSaleModal || e.target.closest('.close-modal')) {
                addSaleModal.style.display = 'none';
            }
        });
    }
    
    // Update stock modal
    document.querySelectorAll('.update-stock-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const productId = this.dataset.productId;
            const productName = this.dataset.productName;
            const currentStock = this.dataset.currentStock;
            
            const modal = document.getElementById('updateStockModal');
            const form = modal.querySelector('form');
            
            form.querySelector('[name="productId"]').value = productId;
            form.querySelector('[name="productName"]').textContent = productName;
            form.querySelector('[name="currentStock"]').textContent = currentStock;
            
            modal.style.display = 'flex';
            
            modal.addEventListener('click', (e) => {
                if (e.target === modal || e.target.closest('.close-modal')) {
                    modal.style.display = 'none';
                }
            });
        });
    });
}

// Initialize form validation
function initFormValidation() {
    const forms = document.querySelectorAll('form[needs-validation]');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            if (!this.checkValidity()) {
                e.preventDefault();
                e.stopPropagation();
            }
            
            this.classList.add('was-validated');
        });
    });
}

// Initialize search functionality
function initSearch() {
    const searchInput = document.getElementById('searchInput');
    if (!searchInput) return;
    
    searchInput.addEventListener('input', function() {
        const searchTerm = this.value.toLowerCase();
        const table = this.closest('.card').querySelector('tbody');
        const rows = table.querySelectorAll('tr');
        
        rows.forEach(row => {
            const text = row.textContent.toLowerCase();
            row.style.display = text.includes(searchTerm) ? '' : 'none';
        });
    });
}

// Auto-hide alerts
function autoHideAlerts() {
    setTimeout(() => {
        document.querySelectorAll('.alert').forEach(alert => {
            alert.style.opacity = '0';
            alert.style.transition = 'opacity 0.5s';
            setTimeout(() => alert.remove(), 500);
        });
    }, 5000);
}

// Confirm delete action
function confirmDelete(action, itemName) {
    if (confirm(`Are you sure you want to delete ${itemName}? This action cannot be undone.`)) {
        window.location.href = action;
    }
}

// Export data to CSV
function exportToCSV(tableId, filename) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    let csv = [];
    const rows = table.querySelectorAll('tr');
    
    rows.forEach(row => {
        const rowData = [];
        const cols = row.querySelectorAll('td, th');
        
        cols.forEach(col => {
            // Remove button text and get clean data
            let text = col.textContent.replace(/Delete|Edit|View/gi, '').trim();
            rowData.push(`"${text}"`);
        });
        
        csv.push(rowData.join(','));
    });
    
    const csvContent = csv.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    
    a.href = url;
    a.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
}

// Quick stock update
function quickStockUpdate(productId, action) {
    const quantity = prompt(`Enter quantity to ${action}:`);
    if (quantity && !isNaN(quantity) && quantity > 0) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = '/stock/update';
        
        const productIdInput = document.createElement('input');
        productIdInput.type = 'hidden';
        productIdInput.name = 'productId';
        productIdInput.value = productId;
        
        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = action;
        
        const quantityInput = document.createElement('input');
        quantityInput.type = 'hidden';
        quantityInput.name = 'quantity';
        quantityInput.value = quantity;
        
        form.appendChild(productIdInput);
        form.appendChild(actionInput);
        form.appendChild(quantityInput);
        
        document.body.appendChild(form);
        form.submit();
    }
}

// Print current page
function printPage() {
    window.print();
}

// Theme toggle (light/dark mode)
function toggleTheme() {
    const html = document.documentElement;
    const currentTheme = html.getAttribute('data-theme');
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    
    html.setAttribute('data-theme', newTheme);
    localStorage.setItem('ims-theme', newTheme);
    
    // Update icon
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = newTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// Initialize theme from localStorage
function initTheme() {
    const savedTheme = localStorage.getItem('ims-theme') || 'light';
    document.documentElement.setAttribute('data-theme', savedTheme);
    
    const themeIcon = document.getElementById('themeIcon');
    if (themeIcon) {
        themeIcon.className = savedTheme === 'dark' ? 'fas fa-sun' : 'fas fa-moon';
    }
}

// Initialize theme on load
initTheme();

// Real-time notifications
function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
        <button onclick="this.parentElement.remove()">&times;</button>
    `;
    
    document.body.appendChild(notification);
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.remove();
        }
    }, 5000);
}

// Add CSS for notifications
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        background: white;
        box-shadow: var(--box-shadow);
        display: flex;
        align-items: center;
        gap: 10px;
        z-index: 9999;
        animation: slideIn 0.3s ease;
        max-width: 400px;
    }
    
    .notification-success {
        border-left: 4px solid #4cc9f0;
    }
    
    .notification-error {
        border-left: 4px solid #f72585;
    }
    
    .notification-info {
        border-left: 4px solid #4361ee;
    }
    
    .notification button {
        background: none;
        border: none;
        font-size: 1.5rem;
        cursor: pointer;
        opacity: 0.5;
    }
    
    .notification button:hover {
        opacity: 1;
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;
document.head.appendChild(notificationStyles);

// Keyboard shortcuts
document.addEventListener('keydown', function(e) {
    // Ctrl + F for search
    if (e.ctrlKey && e.key === 'f') {
        e.preventDefault();
        const searchInput = document.getElementById('searchInput');
        if (searchInput) {
            searchInput.focus();
        }
    }
    
    // Ctrl + P for print
    if (e.ctrlKey && e.key === 'p') {
        e.preventDefault();
        printPage();
    }
    
    // Esc to close modals
    if (e.key === 'Escape') {
        document.querySelectorAll('.modal').forEach(modal => {
            modal.style.display = 'none';
        });
    }
});